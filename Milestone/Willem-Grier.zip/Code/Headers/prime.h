//
// Created by wgrie on 2/25/2021.
//

#ifndef CSE310_P2_PRIME_H
#define CSE310_P2_PRIME_H
int isPrime();
int firstPrime(int m);
#endif //CSE310_P2_PRIME_H
